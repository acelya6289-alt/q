import { Hero } from "./components/Hero";
import { Benefits } from "./components/Benefits";
import { HowItWorks } from "./components/HowItWorks";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { Navbar } from "./components/Navbar";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { HomePage } from "./pages/HomePage";
import { LeistungenPage } from "./pages/LeistungenPage";
import { ReferenzenPage } from "./pages/ReferenzenPage";
import { UeberUnsPage } from "./pages/UeberUnsPage";
import { KontaktPage } from "./pages/KontaktPage";

export default function App() {
  return (
    <Router>
      <div className="min-h-screen">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/leistungen" element={<LeistungenPage />} />
          <Route path="/referenzen" element={<ReferenzenPage />} />
          <Route path="/ueber-uns" element={<UeberUnsPage />} />
          <Route path="/kontakt" element={<KontaktPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}