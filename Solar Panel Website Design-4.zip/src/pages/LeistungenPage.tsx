import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { 
  Sun, 
  Battery, 
  Settings, 
  CheckCircle,
  ArrowRight,
  Zap,
  Shield,
  TrendingUp
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Link } from "react-router-dom";

const services = [
  {
    icon: Sun,
    title: "Photovoltaik-Anlagen",
    description: "Komplette Solaranlagen für Ihr Eigenheim oder Gewerbe",
    image: "https://images.unsplash.com/photo-1668097613572-40b7c11c8727?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMGluc3RhbGxhdGlvbnxlbnwxfHx8fDE3NjQ1MzE0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    features: [
      "Premium Module von führenden Herstellern",
      "Individuelle Planung nach Ihrem Bedarf",
      "Professionelle Installation",
      "25 Jahre Leistungsgarantie",
      "Optimale Ausrichtung und Neigung"
    ],
    details: "Unsere hochwertigen Photovoltaik-Anlagen sind optimal auf Ihre Bedürfnisse abgestimmt. Wir verwenden nur Premiummodule von renommierten Herstellern mit höchster Effizienz und Langlebigkeit."
  },
  {
    icon: Battery,
    title: "Batteriespeicher",
    description: "Speichern Sie Ihren Solarstrom für maximale Unabhängigkeit",
    image: "https://images.unsplash.com/photo-1591964006776-90b32e88f5ec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXR0ZXJ5JTIwc3RvcmFnZSUyMHN5c3RlbXxlbnwxfHx8fDE3NjQ0MTA4NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    features: [
      "Bis zu 90% Autarkie möglich",
      "Notstromfunktion verfügbar",
      "Intelligentes Energiemanagement",
      "10 Jahre Garantie",
      "Erweiterbar und skalierbar"
    ],
    details: "Mit einem modernen Batteriespeicher nutzen Sie Ihren selbst erzeugten Strom auch nachts und an bewölkten Tagen. Erreichen Sie bis zu 90% Unabhängigkeit vom Stromnetz."
  },
  {
    icon: Settings,
    title: "Wartung & Service",
    description: "Rundum-Betreuung für optimale Leistung Ihrer Anlage",
    image: "https://images.unsplash.com/photo-1676337168442-56f47df3972c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMG1haW50ZW5hbmNlJTIwdGVjaG5pY2lhbnxlbnwxfHx8fDE3NjQ0NzkxNzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    features: [
      "Regelmäßige Wartung und Inspektion",
      "Schneller Reparaturservice",
      "Monitoring und Optimierung",
      "Reinigung der Module",
      "24/7 Support-Hotline"
    ],
    details: "Wir sorgen dafür, dass Ihre Solaranlage stets optimal läuft. Mit regelmäßigen Wartungen, professioneller Reinigung und schnellem Service bei Problemen."
  }
];

const additionalServices = [
  {
    icon: Zap,
    title: "Wallbox Installation",
    description: "Laden Sie Ihr E-Auto mit selbst erzeugtem Solarstrom"
  },
  {
    icon: Shield,
    title: "Versicherung & Garantie",
    description: "Umfassender Schutz für Ihre Investition"
  },
  {
    icon: TrendingUp,
    title: "Finanzierung",
    description: "Flexible Finanzierungsmodelle und Fördermittelberatung"
  }
];

export function LeistungenPage() {
  return (
    <div className="pt-16">
      {/* Header */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-6xl mb-6">
              Unsere Leistungen
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Von der Planung über die Installation bis zur langfristigen Betreuung - wir bieten Ihnen alles aus einer Hand
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-24">
            {services.map((service, index) => {
              const Icon = service.icon;
              const isEven = index % 2 === 0;
              
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                    isEven ? "" : "lg:grid-flow-dense"
                  }`}
                >
                  <div className={isEven ? "" : "lg:col-start-2"}>
                    <div className="inline-flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <h2 className="text-3xl md:text-4xl text-foreground">
                        {service.title}
                      </h2>
                    </div>
                    
                    <p className="text-xl text-muted-foreground mb-6">
                      {service.description}
                    </p>
                    
                    <p className="text-lg text-muted-foreground mb-6">
                      {service.details}
                    </p>

                    <div className="space-y-3 mb-8">
                      {service.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                          <span className="text-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <Link to="/kontakt">
                      <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 group">
                        Jetzt beraten lassen
                        <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </div>

                  <div className={isEven ? "" : "lg:col-start-1 lg:row-start-1"}>
                    <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                      <ImageWithFallback
                        src={service.image}
                        alt={service.title}
                        className="w-full h-[400px] object-cover"
                      />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Weitere Services
            </h2>
            <p className="text-xl text-muted-foreground">
              Ihr Komplettpaket für nachhaltige Energie
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {additionalServices.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-4">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-foreground mb-3">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Interesse geweckt?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Kontaktieren Sie uns für ein unverbindliches Beratungsgespräch
            </p>
            <Link to="/kontakt">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 px-8 py-6">
                Kostenlose Beratung anfragen
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
