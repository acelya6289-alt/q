import { Contact } from "../components/Contact";

export function KontaktPage() {
  return (
    <div className="pt-16">
      <Contact />
    </div>
  );
}
