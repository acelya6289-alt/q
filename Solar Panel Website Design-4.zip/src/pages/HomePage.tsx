import { Hero } from "../components/Hero";
import { Benefits } from "../components/Benefits";
import { HowItWorks } from "../components/HowItWorks";
import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export function HomePage() {
  return (
    <>
      <Hero />
      
      {/* Quick Overview Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-4xl md:text-5xl text-foreground mb-6">
                Ihre Experten für Solarenergie
              </h2>
              <p className="text-xl text-muted-foreground mb-6">
                Mit über 15 Jahren Erfahrung und mehr als 10.000 zufriedenen Kunden sind wir Ihr verlässlicher Partner für den Umstieg auf Solarenergie.
              </p>
              <p className="text-lg text-muted-foreground mb-8">
                Von der ersten Beratung über die professionelle Installation bis zur langfristigen Wartung - wir begleiten Sie auf Ihrem Weg zur Energieunabhängigkeit.
              </p>
              <Link to="/ueber-uns">
                <Button size="lg" className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 group">
                  Mehr über uns
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="grid grid-cols-2 gap-4"
            >
              <div className="bg-gradient-to-br from-primary to-secondary p-6 rounded-2xl text-white">
                <div className="text-4xl mb-2">15+</div>
                <div>Jahre Erfahrung</div>
              </div>
              <div className="bg-gradient-to-br from-secondary to-accent p-6 rounded-2xl text-white">
                <div className="text-4xl mb-2">10.000+</div>
                <div>Installationen</div>
              </div>
              <div className="bg-gradient-to-br from-accent to-primary p-6 rounded-2xl text-white">
                <div className="text-4xl mb-2">25</div>
                <div>Jahre Garantie</div>
              </div>
              <div className="bg-gradient-to-br from-primary/80 to-secondary/80 p-6 rounded-2xl text-white">
                <div className="text-4xl mb-2">98%</div>
                <div>Zufriedenheit</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Benefits />
      <HowItWorks />

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Bereit für Ihre Solaranlage?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Lassen Sie sich jetzt kostenlos und unverbindlich beraten
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/kontakt">
                <Button size="lg" className="bg-white text-primary hover:bg-white/90 px-8 py-6">
                  Beratungstermin vereinbaren
                </Button>
              </Link>
              <Link to="/leistungen">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20 px-8 py-6">
                  Unsere Leistungen
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
}
