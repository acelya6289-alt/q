import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { Star, Quote, ArrowRight, MapPin, Calendar, Zap } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Link } from "react-router-dom";

const projects = [
  {
    title: "Einfamilienhaus München",
    category: "Privat",
    location: "München, Bayern",
    year: "2024",
    power: "8,5 kWp",
    image: "https://images.unsplash.com/photo-1602493347312-222218d66a2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3VzZSUyMHNvbGFyfGVufDF8fHx8MTc2NDQ5MjMzNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Komplette PV-Anlage mit Batteriespeicher für maximale Autarkie"
  },
  {
    title: "Produktionshalle Frankfurt",
    category: "Gewerbe",
    location: "Frankfurt, Hessen",
    year: "2024",
    power: "125 kWp",
    image: "https://images.unsplash.com/photo-1612045224533-7a6c7e8a49ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMGZhY3Rvcnl8ZW58MXx8fHwxNzY0NDY2NTMzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Großflächige Solaranlage für industrielle Produktionsstätte"
  },
  {
    title: "Solarpark Stuttgart",
    category: "Großprojekt",
    location: "Stuttgart, Baden-Württemberg",
    year: "2023",
    power: "500 kWp",
    image: "https://images.unsplash.com/photo-1756913455724-6b3a2ae0130b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMGZhcm0lMjBidXNpbmVzc3xlbnwxfHx8fDE3NjQ1MzQ2ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    description: "Freiflächenanlage zur nachhaltigen Energieversorgung"
  }
];

const testimonials = [
  {
    name: "Familie Schneider",
    location: "Hamburg",
    rating: 5,
    text: "Von der Beratung bis zur Installation lief alles perfekt. Unsere Stromkosten sind um 75% gesunken und wir leisten aktiv einen Beitrag zum Klimaschutz. Absolut empfehlenswert!",
    project: "8 kWp Anlage mit Speicher"
  },
  {
    name: "Thomas Weber",
    location: "Berlin",
    rating: 5,
    text: "Professionelle Arbeit und faire Preise. Die Anlage läuft seit 2 Jahren problemlos und produziert sogar mehr als ursprünglich berechnet. Super Service!",
    project: "6,5 kWp Anlage"
  },
  {
    name: "Müller GmbH",
    location: "Köln",
    rating: 5,
    text: "Als Gewerbebetrieb sind wir sehr zufrieden. Die Installation wurde termingerecht durchgeführt und die Anlage amortisiert sich schneller als erwartet.",
    project: "45 kWp Gewerbeanlage"
  },
  {
    name: "Sarah Klein",
    location: "Dresden",
    rating: 5,
    text: "Kompetente Beratung und transparente Kommunikation während des gesamten Projekts. Das Team war immer erreichbar und hat alle Fragen ausführlich beantwortet.",
    project: "7 kWp Anlage"
  },
  {
    name: "Fischer Logistik",
    location: "Nürnberg",
    rating: 5,
    text: "Unsere Logistikhalle ist jetzt energieautark. Die Planung war sehr durchdacht und die Umsetzung professionell. Wir würden jederzeit wieder mit SolarPro arbeiten.",
    project: "180 kWp Gewerbeanlage"
  },
  {
    name: "Familie Hoffmann",
    location: "Leipzig",
    rating: 5,
    text: "Wir sind begeistert von unserer neuen Solaranlage! Die Investition hat sich bereits nach 3 Jahren gelohnt und wir sind fast komplett unabhängig vom Stromnetz.",
    project: "9 kWp Anlage mit Speicher"
  }
];

const stats = [
  { value: "10.000+", label: "Installierte Anlagen" },
  { value: "98%", label: "Zufriedene Kunden" },
  { value: "150 MW", label: "Installierte Leistung" },
  { value: "15+", label: "Jahre Erfahrung" }
];

export function ReferenzenPage() {
  return (
    <div className="pt-16">
      {/* Header */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-6xl mb-6">
              Referenzen
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Überzeugen Sie sich von unserer Arbeit und den Erfahrungen unserer zufriedenen Kunden
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl text-primary mb-2">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Unsere Projekte
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Beispiele erfolgreich realisierter Solaranlagen
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="relative h-64">
                  <ImageWithFallback
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-primary text-white px-3 py-1 rounded-full text-sm">
                    {project.category}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-foreground mb-3">{project.title}</h3>
                  <p className="text-muted-foreground mb-4">{project.description}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{project.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>{project.year}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Zap className="w-4 h-4" />
                      <span>{project.power}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Kundenstimmen
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Was unsere Kunden über uns sagen
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-muted p-6 rounded-2xl relative"
              >
                <Quote className="w-10 h-10 text-primary/20 absolute top-4 right-4" />
                
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-secondary text-secondary" />
                  ))}
                </div>

                <p className="text-foreground mb-4 relative z-10">
                  "{testimonial.text}"
                </p>

                <div className="pt-4 border-t border-border">
                  <div className="text-foreground mb-1">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground mb-2">{testimonial.location}</div>
                  <div className="text-sm text-primary">{testimonial.project}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Werden Sie unser nächstes Erfolgsprojekt
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Lassen Sie sich jetzt kostenlos beraten und werden Sie Teil unserer Erfolgsgeschichte
            </p>
            <Link to="/kontakt">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 px-8 py-6 group">
                Jetzt Kontakt aufnehmen
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
