import { motion } from "motion/react";
import { Button } from "../components/ui/button";
import { 
  Target, 
  Award, 
  Users, 
  Heart,
  CheckCircle,
  ArrowRight,
  Leaf,
  Shield,
  Lightbulb
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Link } from "react-router-dom";

const values = [
  {
    icon: Target,
    title: "Qualität",
    description: "Höchste Standards bei Produkten und Installation"
  },
  {
    icon: Heart,
    title: "Kundenzufriedenheit",
    description: "Ihr Erfolg ist unser Erfolg - 98% zufriedene Kunden"
  },
  {
    icon: Leaf,
    title: "Nachhaltigkeit",
    description: "Aktiver Beitrag zum Klimaschutz und zur Energiewende"
  },
  {
    icon: Shield,
    title: "Zuverlässigkeit",
    description: "Verlässlicher Partner von der Planung bis zur Wartung"
  }
];

const milestones = [
  {
    year: "2009",
    title: "Firmengründung",
    description: "Start als kleines Team mit großer Vision"
  },
  {
    year: "2012",
    title: "1.000 Installationen",
    description: "Erreichen des ersten großen Meilensteins"
  },
  {
    year: "2016",
    title: "Expansion",
    description: "Eröffnung weiterer Standorte in Deutschland"
  },
  {
    year: "2020",
    title: "5.000 Anlagen",
    description: "Verdoppelung der installierten Leistung"
  },
  {
    year: "2024",
    title: "10.000+ Kunden",
    description: "Führender Anbieter in der Region"
  }
];

const team = [
  {
    name: "Dr. Michael Schmidt",
    role: "Geschäftsführer",
    description: "Elektroingenieur mit 20 Jahren Erfahrung in erneuerbaren Energien"
  },
  {
    name: "Sarah Weber",
    role: "Technische Leiterin",
    description: "Expertin für PV-Systeme und innovative Solartechnologien"
  },
  {
    name: "Thomas Müller",
    role: "Vertriebsleiter",
    description: "Spezialist für Kundenberatung und maßgeschneiderte Lösungen"
  },
  {
    name: "Lisa Hoffmann",
    role: "Projektmanagerin",
    description: "Verantwortlich für reibungslose Projektabläufe"
  }
];

const certifications = [
  "TÜV-zertifizierter Fachbetrieb",
  "Meisterbetrieb der Elektrotechnik",
  "Zertifizierte Installateure aller großen Hersteller",
  "ISO 9001 Qualitätsmanagement",
  "Mitglied im Bundesverband Solarwirtschaft"
];

export function UeberUnsPage() {
  return (
    <div className="pt-16">
      {/* Header */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-6xl mb-6">
              Über uns
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              Ihr erfahrener Partner für nachhaltige Energielösungen seit über 15 Jahren
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-4xl md:text-5xl text-foreground mb-6">
                Unsere Geschichte
              </h2>
              <p className="text-lg text-muted-foreground mb-4">
                SolarPro wurde 2009 mit der Vision gegründet, saubere Energie für jeden zugänglich zu machen. Was als kleines Team von Enthusiasten begann, ist heute einer der führenden Anbieter für Photovoltaik-Lösungen in Deutschland.
              </p>
              <p className="text-lg text-muted-foreground mb-4">
                Mit über 10.000 erfolgreich installierten Anlagen und einer Kundenzufriedenheit von 98% haben wir bewiesen, dass Qualität und Service unser höchstes Gut sind.
              </p>
              <p className="text-lg text-muted-foreground mb-6">
                Unser engagiertes Team aus Ingenieuren, Technikern und Beratern arbeitet täglich daran, die Energiewende voranzutreiben und unseren Kunden den bestmöglichen Service zu bieten.
              </p>
              <Link to="/kontakt">
                <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 group">
                  Jetzt beraten lassen
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="rounded-2xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1581093805071-a04e696db334?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlYW0lMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzY0NDkzMjY5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Unser Team"
                  className="w-full h-[500px] object-cover"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Unsere Werte
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Was uns antreibt und auszeichnet
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white p-6 rounded-2xl text-center shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-foreground mb-2">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Unsere Meilensteine
            </h2>
            <p className="text-xl text-muted-foreground">
              Eine Erfolgsgeschichte in Zahlen
            </p>
          </motion.div>

          <div className="space-y-8">
            {milestones.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="flex gap-8 items-start"
              >
                <div className="flex-shrink-0 w-24 text-right">
                  <div className="text-3xl text-primary">{milestone.year}</div>
                </div>
                <div className="relative flex-shrink-0">
                  <div className="w-4 h-4 rounded-full bg-primary"></div>
                  {index < milestones.length - 1 && (
                    <div className="absolute left-1/2 top-4 w-0.5 h-16 bg-primary/30 -translate-x-1/2"></div>
                  )}
                </div>
                <div className="flex-1 pb-8">
                  <h3 className="text-foreground mb-2">{milestone.title}</h3>
                  <p className="text-muted-foreground">{milestone.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Unser Team
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experten mit Leidenschaft für Solarenergie
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-6 rounded-2xl text-center shadow-lg"
              >
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-4">
                  <Users className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-foreground mb-1">{member.name}</h3>
                <div className="text-primary mb-3">{member.role}</div>
                <p className="text-sm text-muted-foreground">{member.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Zertifizierungen & Mitgliedschaften
            </h2>
            <p className="text-xl text-muted-foreground">
              Qualität, auf die Sie sich verlassen können
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-muted p-8 rounded-2xl"
          >
            <div className="space-y-4">
              {certifications.map((cert, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-center gap-4"
                >
                  <CheckCircle className="w-6 h-6 text-primary flex-shrink-0" />
                  <span className="text-lg text-foreground">{cert}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl text-white mb-6">
              Lernen Sie uns kennen
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Vereinbaren Sie einen Termin für ein persönliches Beratungsgespräch
            </p>
            <Link to="/kontakt">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 px-8 py-6">
                Jetzt Kontakt aufnehmen
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
