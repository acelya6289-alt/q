# Solaranlagen Website

Eine moderne, responsive Website für Solaranlagen mit React, TypeScript und Tailwind CSS.

## 🚀 Deployment auf Netlify

### Option 1: Über Netlify Dashboard (Einfachste Methode)

1. **Projekt vorbereiten:**
   - Alle Dateien in ein Git-Repository hochladen (GitHub, GitLab oder Bitbucket)

2. **Netlify Setup:**
   - Gehen Sie zu [netlify.com](https://netlify.com) und melden Sie sich an
   - Klicken Sie auf "Add new site" → "Import an existing project"
   - Verbinden Sie Ihr Git-Repository
   - Netlify erkennt automatisch die Einstellungen aus `netlify.toml`
   - Klicken Sie auf "Deploy site"

### Option 2: Über Netlify CLI

```bash
# Netlify CLI installieren
npm install -g netlify-cli

# In Ihr Projekt-Verzeichnis wechseln
cd /pfad/zu/ihrem/projekt

# Dependencies installieren
npm install

# Build erstellen
npm run build

# Bei Netlify einloggen
netlify login

# Website deployen
netlify deploy --prod
```

### Option 3: Manueller Upload

1. **Build lokal erstellen:**
   ```bash
   npm install
   npm run build
   ```

2. **Deploy:**
   - Gehen Sie zu [netlify.com](https://netlify.com)
   - Ziehen Sie den `dist` Ordner per Drag & Drop auf die Netlify-Seite

## 📁 Projektstruktur

```
/
├── components/          # React-Komponenten
│   ├── ui/             # ShadCN UI-Komponenten
│   ├── Hero.tsx
│   ├── Benefits.tsx
│   ├── HowItWorks.tsx
│   ├── Contact.tsx
│   ├── Footer.tsx
│   └── Navbar.tsx
├── pages/              # Seiten-Komponenten
│   ├── HomePage.tsx
│   ├── LeistungenPage.tsx
│   ├── ReferenzenPage.tsx
│   ├── UeberUnsPage.tsx
│   └── KontaktPage.tsx
├── styles/
│   └── globals.css     # Globale Styles
├── App.tsx             # Haupt-App-Komponente
├── main.tsx            # Entry Point
├── index.html          # HTML Template
├── package.json        # Dependencies
├── netlify.toml        # Netlify-Konfiguration
└── vite.config.ts      # Vite-Konfiguration
```

## 🛠️ Lokale Entwicklung

```bash
# Dependencies installieren
npm install

# Entwicklungsserver starten
npm run dev

# Build für Produktion erstellen
npm run build

# Build-Vorschau lokal testen
npm run preview
```

## 🌐 Features

- ✅ Multi-Page-Website mit React Router
- ✅ Vollständig responsive Design
- ✅ Moderne UI mit ShadCN-Komponenten
- ✅ Tailwind CSS für Styling
- ✅ TypeScript für Type-Safety
- ✅ Optimiert für Netlify-Deployment
- ✅ SEO-freundlich

## 📋 Seiten

- **/** - Startseite mit Hero, Benefits und How It Works
- **/leistungen** - Übersicht der Dienstleistungen
- **/referenzen** - Kundenprojekte und Referenzen
- **/ueber-uns** - Informationen über das Unternehmen
- **/kontakt** - Kontaktformular

## 🎨 Design

- Farbschema: Dunkelblau (#1e3a8a) mit gelben Akzenten (#fbbf24)
- Moderne, professionelle Optik
- Optimiert für Desktop und Mobile

## 📝 Nächste Schritte

Um das Kontaktformular funktionsfähig zu machen, können Sie:
1. **Netlify Forms** nutzen (einfachste Option, kostenlos)
2. **Formspree** oder ähnliche Services integrieren
3. **Supabase** für Backend-Funktionalität hinzufügen

## 🔧 Technologie-Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS 4
- React Router DOM
- ShadCN UI
- Lucide Icons

## 📄 Lizenz

Dieses Projekt wurde für Ihre Solaranlagen-Website erstellt.
