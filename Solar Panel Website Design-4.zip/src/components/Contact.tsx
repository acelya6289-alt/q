import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Mail, Phone, MapPin, Send } from "lucide-react";

export function Contact() {
  return (
    <section id="kontakt" className="py-24 bg-gradient-to-b from-muted to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-black mb-4">
            Bereit für Ihre Solaranlage?
          </h2>
          <p className="text-xl text-black/90 max-w-2xl mx-auto">
            Kontaktieren Sie uns jetzt für eine kostenlose Beratung
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-white/95 backdrop-blur-sm p-8 rounded-2xl shadow-2xl"
          >
            <h3 className="text-foreground mb-6">Anfrage senden</h3>
            <form className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-2 text-foreground">Vorname</label>
                  <Input placeholder="Max" className="bg-input-background" />
                </div>
                <div>
                  <label className="block text-sm mb-2 text-foreground">Nachname</label>
                  <Input placeholder="Mustermann" className="bg-input-background" />
                </div>
              </div>
              <div>
                <label className="block text-sm mb-2 text-foreground">E-Mail</label>
                <Input type="email" placeholder="max@beispiel.de" className="bg-input-background" />
              </div>
              <div>
                <label className="block text-sm mb-2 text-foreground">Telefon</label>
                <Input type="tel" placeholder="+49 123 456789" className="bg-input-background" />
              </div>
              <div>
                <label className="block text-sm mb-2 text-foreground">Nachricht</label>
                <Textarea 
                  placeholder="Erzählen Sie uns von Ihrem Projekt..." 
                  rows={4}
                  className="bg-input-background"
                />
              </div>
              <Button className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90 text-white group">
                Anfrage absenden
                <Send className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </form>
          </motion.div>

          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex flex-col justify-center space-y-8"
          >
            <div>
              <h3 className="text-black mb-6">Kontaktinformationen</h3>
              <div className="space-y-6">
                <motion.div
                  whileHover={{ x: 5 }}
                  className="flex items-start gap-4"
                >
                  <div className="w-12 h-12 rounded-full bg-black/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <div className="text-black/80 mb-1">Telefon</div>
                    <div className="text-black">+49 (0) 123 456 789</div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ x: 5 }}
                  className="flex items-start gap-4"
                >
                  <div className="w-12 h-12 rounded-full bg-black/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <div className="text-black/80 mb-1">E-Mail</div>
                    <div className="text-black">info@solaranlage.de</div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ x: 5 }}
                  className="flex items-start gap-4"
                >
                  <div className="w-12 h-12 rounded-full bg-black/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-black" />
                  </div>
                  <div>
                    <div className="text-black/80 mb-1">Adresse</div>
                    <div className="text-black">
                      Musterstraße 123<br />
                      12345 Musterstadt
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-black/10 backdrop-blur-sm p-6 rounded-2xl border border-black/20"
            >
              <h4 className="text-black mb-3">Öffnungszeiten</h4>
              <div className="space-y-2 text-black/80">
                <div className="flex justify-between">
                  <span>Mo - Fr:</span>
                  <span>08:00 - 18:00 Uhr</span>
                </div>
                <div className="flex justify-between">
                  <span>Sa:</span>
                  <span>09:00 - 14:00 Uhr</span>
                </div>
                <div className="flex justify-between">
                  <span>So:</span>
                  <span>Geschlossen</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}