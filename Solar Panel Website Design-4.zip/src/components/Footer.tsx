import { Sun, Facebook, Instagram, Linkedin, Mail } from "lucide-react";
import { Link } from "react-router-dom";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Sun className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl">SolarPro</span>
            </Link>
            <p className="text-slate-400">
              Ihr Partner für nachhaltige Energie und eine grünere Zukunft.
            </p>
          </div>

          {/* Services */}
          <div>
            <h4 className="mb-4">Leistungen</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link to="/leistungen" className="hover:text-white transition-colors">
                  Solaranlagen
                </Link>
              </li>
              <li>
                <Link to="/leistungen" className="hover:text-white transition-colors">
                  Batteriespeicher
                </Link>
              </li>
              <li>
                <Link to="/leistungen" className="hover:text-white transition-colors">
                  Wallboxen
                </Link>
              </li>
              <li>
                <Link to="/leistungen" className="hover:text-white transition-colors">
                  Wartung & Service
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="mb-4">Unternehmen</h4>
            <ul className="space-y-2 text-slate-400">
              <li>
                <Link to="/ueber-uns" className="hover:text-white transition-colors">
                  Über uns
                </Link>
              </li>
              <li>
                <Link to="/referenzen" className="hover:text-white transition-colors">
                  Referenzen
                </Link>
              </li>
              <li>
                <Link to="/kontakt" className="hover:text-white transition-colors">
                  Karriere
                </Link>
              </li>
              <li>
                <Link to="/kontakt" className="hover:text-white transition-colors">
                  Kontakt
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="mb-4">Newsletter</h4>
            <p className="text-slate-400 mb-4">
              Bleiben Sie auf dem Laufenden über neue Technologien und Angebote.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Ihre E-Mail"
                className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg focus:outline-none focus:border-primary text-sm"
              />
              <button className="px-4 py-2 bg-gradient-to-r from-primary to-secondary rounded-lg hover:opacity-90 transition-opacity">
                <Mail className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-slate-400 text-sm">
            © 2025 SolarPro. Alle Rechte vorbehalten.
          </div>

          {/* Social Media */}
          <div className="flex gap-4">
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-slate-800 hover:bg-primary flex items-center justify-center transition-colors"
            >
              <Facebook className="w-5 h-5" />
            </a>
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-slate-800 hover:bg-primary flex items-center justify-center transition-colors"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a
              href="#"
              className="w-10 h-10 rounded-full bg-slate-800 hover:bg-primary flex items-center justify-center transition-colors"
            >
              <Linkedin className="w-5 h-5" />
            </a>
          </div>

          {/* Legal Links */}
          <div className="flex gap-6 text-sm text-slate-400">
            <a href="#" className="hover:text-white transition-colors">
              Impressum
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Datenschutz
            </a>
            <a href="#" className="hover:text-white transition-colors">
              AGB
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}