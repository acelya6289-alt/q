import { motion } from "motion/react";
import { 
  Zap, 
  TrendingDown, 
  Shield, 
  Leaf, 
  Home, 
  Award,
  Battery,
  Settings
} from "lucide-react";

const benefits = [
  {
    icon: TrendingDown,
    title: "Kosten senken",
    description: "Reduzieren Sie Ihre Stromrechnung um bis zu 80% durch eigene Energieerzeugung"
  },
  {
    icon: Leaf,
    title: "Umweltfreundlich",
    description: "100% saubere Energie und aktiver Beitrag zum Klimaschutz"
  },
  {
    icon: Zap,
    title: "Unabhängigkeit",
    description: "Machen Sie sich unabhängig von steigenden Strompreisen"
  },
  {
    icon: Shield,
    title: "25 Jahre Garantie",
    description: "Langlebige Qualität mit umfassender Herstellergarantie"
  },
  {
    icon: Home,
    title: "Wertsteigerung",
    description: "Erhöhen Sie den Wert Ihrer Immobilie nachhaltig"
  },
  {
    icon: Award,
    title: "Premium Qualität",
    description: "Nur hochwertige Module von führenden Herstellern"
  },
  {
    icon: Battery,
    title: "Speicherlösungen",
    description: "Optional mit Batteriespeicher für maximale Autarkie"
  },
  {
    icon: Settings,
    title: "Rundum-Service",
    description: "Von der Planung bis zur Installation - alles aus einer Hand"
  }
];

export function Benefits() {
  return (
    <section id="vorteile" className="py-24 bg-gradient-to-b from-white to-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-foreground mb-4">
            Warum eine Solaranlage?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Investieren Sie in Ihre Zukunft mit nachhaltiger Energie
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-lg transition-all border border-border"
              >
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                  className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-4"
                >
                  <Icon className="w-7 h-7 text-white" />
                </motion.div>
                <h3 className="text-foreground mb-2">
                  {benefit.title}
                </h3>
                <p className="text-muted-foreground">
                  {benefit.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}