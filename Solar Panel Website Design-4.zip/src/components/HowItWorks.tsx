import { motion } from "motion/react";
import { Phone, Home, Wrench, Sun } from "lucide-react";

const steps = [
  {
    icon: Phone,
    title: "Kostenlose Beratung",
    description: "Kontaktieren Sie uns für eine unverbindliche Erstberatung. Wir analysieren Ihr Dach und Ihren Energiebedarf.",
    step: "01"
  },
  {
    icon: Home,
    title: "Individuelle Planung",
    description: "Unsere Experten erstellen ein maßgeschneidertes Anlagenkonzept für maximale Effizienz und Ertrag.",
    step: "02"
  },
  {
    icon: Wrench,
    title: "Professionelle Installation",
    description: "Unser erfahrenes Team installiert Ihre Solaranlage schnell und fachgerecht - alles aus einer Hand.",
    step: "03"
  },
  {
    icon: Sun,
    title: "Saubere Energie genießen",
    description: "Lehnen Sie sich zurück und genießen Sie Ihre eigene, nachhaltige Energieproduktion.",
    step: "04"
  }
];

export function HowItWorks() {
  return (
    <section id="prozess" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-foreground mb-4">
            So einfach geht's
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            In nur 4 Schritten zu Ihrer eigenen Solaranlage
          </p>
        </motion.div>

        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-primary transform -translate-y-1/2 opacity-20"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="relative"
                >
                  {/* Step Number */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.2 + 0.3 }}
                    className="absolute -top-4 -right-4 w-16 h-16 rounded-full bg-accent flex items-center justify-center border-4 border-white shadow-lg z-10"
                  >
                    <span className="text-2xl text-accent-foreground">{step.step}</span>
                  </motion.div>

                  <div className="bg-gradient-to-br from-muted to-white p-8 rounded-2xl border border-border h-full relative overflow-hidden group hover:shadow-lg transition-shadow">
                    {/* Animated background gradient on hover */}
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    
                    <div className="relative z-10">
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        transition={{ duration: 0.3 }}
                        className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-6"
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </motion.div>

                      <h3 className="text-foreground mb-3">
                        {step.title}
                      </h3>
                      <p className="text-muted-foreground">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}